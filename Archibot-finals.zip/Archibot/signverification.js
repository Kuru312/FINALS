import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js';
import { getAuth, signInWithEmailAndPassword, RecaptchaVerifier, signInWithPhoneNumber } from 'https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js';

const firebaseConfig = {
    apiKey: "AIzaSyDEz-MaD_r4_l-WzROeUQ3fl8SzkZqMpT0",
    authDomain: "archbot-421414.firebaseapp.com",
    projectId: "archbot-421414",
    storageBucket: "archbot-421414.appspot.com",
    messagingSenderId: "287290570947",
    appId: "1:287290570947:web:e50768e780f763a7428a76",
    measurementId: "G-PXCEJFE2H8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

document.addEventListener('DOMContentLoaded', () => {
    const loginButton = document.getElementById('loginButton');
    const sendCodeButton = document.getElementById('sendCodeButton');
    const verifyCodeButton = document.getElementById('verifyCodeButton');

    const loginError = document.getElementById('login-error');
    const phoneError = document.getElementById('phone-error');
    const codeError = document.getElementById('code-error');

    loginButton.addEventListener('click', async (event) => {
        event.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            await signInWithEmailAndPassword(auth, email, password);
            document.getElementById('login-section').style.display = 'none';
            document.getElementById('phone-verification-section').style.display = 'block';

            window.recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', {
                'size': 'normal',
                'callback': (response) => {
                    console.log('Recaptcha verified');
                }
            }, auth);
            recaptchaVerifier.render();

        } catch (error) {
            loginError.textContent = error.message;
        }
    });

    sendCodeButton.addEventListener('click', async (event) => {
        event.preventDefault();
        const phoneNumber = document.getElementById('phone-number').value;

        try {
            const appVerifier = window.recaptchaVerifier;
            const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
            window.confirmationResult = confirmationResult;
            document.getElementById('phone-verification-section').style.display = 'none';
            document.getElementById('code-verification-section').style.display = 'block';
        } catch (error) {
            phoneError.textContent = error.message;
        }
    });

    verifyCodeButton.addEventListener('click', async (event) => {
        event.preventDefault();
        const code = document.getElementById('verification-code').value;

        try {
            const result = await window.confirmationResult.confirm(code);
            const user = result.user;
            window.location.href = 'Archdash.html';
        } catch (error) {
            codeError.textContent = error.message;
        }
    });
});

  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
  import { getAuth, GoogleAuthProvider,signInWithPopup } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";

  const firebaseConfig = {
    apiKey: "AIzaSyDEz-MaD_r4_l-WzROeUQ3fl8SzkZqMpT0",
    authDomain: "archbot-421414.firebaseapp.com",
    projectId: "archbot-421414",
    storageBucket: "archbot-421414.appspot.com",
    messagingSenderId: "287290570947",
    appId: "1:287290570947:web:e50768e780f763a7428a76",
    measurementId: "G-PXCEJFE2H8"
  };

  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);

  auth.languageCode = 'it'
  const provider = new GoogleAuthProvider();

  const googlelogin = document.getElementById("login");
  googlelogin.addEventListener("click",function(){
    signInWithPopup(auth, provider)
    .then((result) => {
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential.accessToken;
    const user = result.user;
    console.log(user);
    window.location.href ="Archdash.html";

  }).catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    const email = error.customData.email;
    const credential = GoogleAuthProvider.credentialFromError(error);
  });

  })
  